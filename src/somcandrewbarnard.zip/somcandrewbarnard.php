<?php

/*
Plugin Name: SonyMobile.com Subpage
Author: Andrew Barnard
Plugin URI: 
Description: A test plugin for SonyMobile.com dev test to display all subpages of the page it placed in 
Version: 1.0
Author URI: 
License: GPL2
*/

function list_pages_shortcode( $atts ) {

    global $post;  
      
    //query subpages  
    $args = array(  
        'post_parent' => $post->ID,  
        'post_type' => 'page',
    );  
    $subpages = new WP_query($args);  
      
    // create output  
    if ($subpages->have_posts()) :  
        $output = '<ul>';  
        while ($subpages->have_posts()) : $subpages->the_post();  
            $output .= '<li><strong><a href="'.get_permalink().'">'.get_the_title().'</a></strong> 
                        <p><a href="'.get_permalink().'">Continue Reading →</a></p>
                        </li>';  
        endwhile;  
        $output .= '</ul>';  
    else :  
        $output = '<p>No subpages found.</p>';  
    endif;  
      
    // reset the query  
    wp_reset_postdata();  
      
    // return something  
    return $output;  
}
add_shortcode( 'list_subpages', 'list_pages_shortcode' );

?>